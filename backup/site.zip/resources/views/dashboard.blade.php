@extends('layouts.primary')
@section('content') 
    <div class=" row">
        <div class="col">
            <h5 class=" text-secondary fw-bolder">
                {{__('Dashboard')}}
            </h5>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="card bg-purple-light">
                <div class="card-body">
                    <div class="row">
                        <div class="">
                            <h4 class="fw-bolder">{{__('Hello,')}}</h4>   <h5
                                class="text-secondary fw-bolder d-sm-inline d-none ">@if (!empty($user)) {{$user->first_name}} {{$user->last_name}}@endif</h5>
                                @if(Session::has('stripe_paid'))
                            <p class="text-primary  fw-bolder mt-3">{{Session::get('stripe_paid')}}</p> @endif

                        </div>


                    </div>
                   

                </div>

            </div>
        </div>

        <div class="col-md-6">
            <div class=" ">
                <div class="">
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-body p-3">
                                    Sample Panel

                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 mb-4">
                            <div class="card bg-success">
                                <div class="card-body p-3">
                             Sample Panel
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card ">
                                <div class="card-body p-3">
                                Sample Panel
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 mb-xl-0 mb-4">
                            <div class="card bg-secondary">
                                <div class="card-body  p-3">
                                     Sample Panel
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    
@endsection






