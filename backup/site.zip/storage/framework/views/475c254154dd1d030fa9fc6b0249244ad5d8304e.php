<?php $__env->startSection('content'); ?>
    <div class=" row">
        <div class="col">
            <h5 class=" text-secondary fw-bolder">
                <?php echo e(__('Settings')); ?>

            </h5>
        </div>
        <div class="col text-end">
        </div>
    </div>
    <div class="row mb-5">
        <div class="  col-md-8 mt-lg-0 mt-4">
            <div class="card">
                <div class="card-body">
                    <form enctype="multipart/form-data" action="<?php echo e(route('/settings')); ?>" method="post">

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul class="list-unstyled">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <div class="mt-4" id="basic-info">
                            <div class=" pt-0">
                                <div class="row">
                                    <label class="form-label"><?php echo e(__('Workspace Name')); ?></label>

                                    <div class="input-group">
                                        <input id="firstName" name="workspace_name" value="<?php echo e($workspace->name); ?>"
                                               class="form-control" type="text" required="required">
                                    </div>
                                </div>

                                <?php if($user->super_admin): ?>
                                    <div class="row">
                                        <div class="col-md-12 align-self-center">
                                            <div>
                                                <label for="logo_file" class="form-label mt-4"><?php echo e(__('Upload Logo')); ?></label>
                                                <input class="form-control" name="logo" type="file" id="logo_file">
                                            </div>
                                        </div>
                                    </div>

                                <?php endif; ?>
                                <?php if($user->super_admin): ?>
                                    <label class="form-label mt-3"><?php echo e(__('Currency')); ?></label>

                                    <div class="input-group">
                                        <input id="currency" name="currency" value="<?php echo e($settings['currency'] ?? config('app.currency')); ?>"
                                               class="form-control" type="text" required="required">
                                    </div>

                                <?php endif; ?>
                                <?php if($user->super_admin): ?>
                                    <div class="row">
                                        <div class="col-md-12 align-self-center">
                                            <div>
                                                <label for="free_trial_days" class="form-label mt-4"><?php echo e(__('Free Trial Days')); ?></label>
                                                <input class="form-control" name="free_trial_days" type="number" id="free_trial_days" value="<?php echo e($settings['free_trial_days'] ?? ''); ?>">
                                            </div>
                                        </div>
                                    </div>

                                <?php endif; ?>

                                <?php echo csrf_field(); ?>
                                <button class="btn btn-info btn-sm float-left mt-4 mb-0"><?php echo e(__('Update')); ?> </button>
                            </div>
                        </div>
                    </form>

                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.'.($layout ?? 'primary'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_projects\spark\resources\views/settings/settings.blade.php ENDPATH**/ ?>