<?php $__env->startSection('content'); ?> 
    <div class=" row">
        <div class="col">
            <h5 class=" text-secondary fw-bolder">
                <?php echo e(__('Dashboard')); ?>

            </h5>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="card bg-purple-light">
                <div class="card-body">
                    <div class="row">
                        <div class="">
                            <h4 class="fw-bolder"><?php echo e(__('Hello,')); ?></h4>   <h5
                                class="text-secondary fw-bolder d-sm-inline d-none "><?php if(!empty($user)): ?> <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?><?php endif; ?></h5>
                                <?php if(Session::has('stripe_paid')): ?>
                            <p class="text-primary  fw-bolder mt-3"><?php echo e(Session::get('stripe_paid')); ?></p> <?php endif; ?>

                        </div>


                    </div>
                   

                </div>

            </div>
        </div>

        <div class="col-md-6">
            <div class=" ">
                <div class="">
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-body p-3">
                                    Sample Panel

                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 mb-4">
                            <div class="card bg-success">
                                <div class="card-body p-3">
                             Sample Panel
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card ">
                                <div class="card-body p-3">
                                Sample Panel
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 mb-xl-0 mb-4">
                            <div class="card bg-secondary">
                                <div class="card-body  p-3">
                                     Sample Panel
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    
<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.primary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_projects\spark\resources\views/dashboard.blade.php ENDPATH**/ ?>