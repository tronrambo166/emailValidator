/*!
 * Alan Da Silva - Viwari (https://codecanyon.net/user/viwari/portfolio)
 * Copyright 2017 Berevi Collection
 * Licensed (https://codecanyon.net/licenses/standard)
 * See full license https://codecanyon.net/licenses/terms/regular
 */

$(function () {
  	'use strict'

  	$('[data-toggle="offcanvas"]').on('click', function () {
    	$('.row-offcanvas').toggleClass('active')
  	})
})
