# Release Instructions

1. Create a new GitHub release ("v2.0.2") with the release notes
2. [Create the release on the Nova backend](https://spark.laravel.com/nova/resources/releases) using the same release name "v2.0.2"
