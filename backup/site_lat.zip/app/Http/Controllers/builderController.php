<?php

namespace App\Http\Controllers;  
//use App\Validation\Controller;
use Illuminate\Http\Request;
use App\Validation\Standardize;
use App\Validation\MailCleaner;
use App\Validation\BounceMailHandler;
use  App\Http\Controllers\fileController;


class builderController extends BaseController
{

     public function __construct()
    {
        parent::__construct();
    }


    public function home()
    {
        return view('builder.mail-cleaner');
    }


     public function clean_mail(Request $request)
    {   
        $fileName = $request->name.'.txt'; 
        if($request->name == '') $fileName = 'emails.txt';
        $emails= array();$i=0; //return $request->all();

        if($request->fileInput!=null) 
        { 
        $inputFile = $request->file('fileInput');
        $emails = fileController::convert($inputFile, ',');
        if(!$emails) return "Please include a colum 'Emails' at line 1 in your cse file"; 
         foreach($emails as $e)
         {
         $e = $this->clean($e);  
         $emails[$i] = $e;$i++; 
         }  
        }
        else
        {
        $all= explode(PHP_EOL,$request->emails); 
            foreach($all as $e)
            {
             $e = $this->clean($e);  
             $emails[$i] = $e; $i++; 
            }
            
        }

        

        $order = $request->ascOrDesc;
        $tld_Sld = $request->tldAndSld;
        

        $emails=$this->sorter($tld_Sld,$order,$emails);
        //return print_r($emails);


        header("Content-type: text/csv");
        header("Cache-Control: no-store, no-cache");
        header('Content-Disposition: attachment; filename='.$fileName);
        $file = fopen('php://output','w');
        foreach($emails as $email) echo $email.PHP_EOL;
           
                
    }


    public function clean($string)
    {
        $string = str_replace(' ', '', $string);
       
        $string = preg_replace('/[^A-Za-z0-9-@.\-]/', '', $string); //echo $string; exit;
        return $string = str_replace('..', '.', $string);
    }


    public function sorter($domainLevel, $order, array $emails = array())
    {
        if ($domainLevel == "tld") {
            $newlines = [];
            foreach ($emails as $email) {
                $newlines[] = strrev($email);
            }

            if ($order == "asc") {
                sort($newlines, SORT_NATURAL | SORT_FLAG_CASE);
            } elseif ($order == "desc") {
                rsort($newlines, SORT_NATURAL | SORT_FLAG_CASE);
            } else {
                sort($newlines, SORT_NATURAL | SORT_FLAG_CASE);
            }

            foreach ($newlines as $email) {
                $reallines[] = strrev($email);
            }

            return $reallines;
        } elseif ($domainLevel == "ccTld") {
            $a = $b = $ax = $bx = [];
            foreach ($emails as $email) {
                $x = substr(strrev(trim($email)), 0, 3);
                (strpos($x, '.') !== false) ? $a[] = strrev($email) : $b[] = strrev($email);
            }

            if ($order == "asc") {
                sort($a, SORT_NATURAL | SORT_FLAG_CASE);
                sort($b, SORT_NATURAL | SORT_FLAG_CASE);
            } elseif ($order == "desc") {
                rsort($a, SORT_NATURAL | SORT_FLAG_CASE);
                rsort($b, SORT_NATURAL | SORT_FLAG_CASE);
            } else {
                sort($a, SORT_NATURAL | SORT_FLAG_CASE);
                sort($b, SORT_NATURAL | SORT_FLAG_CASE);
            }

            foreach ($a as $lineA) {
                $ax[] = strrev($lineA);
            }

            foreach ($b as $lineB) {
                $bx[] = strrev($lineB);
            }

            return array_merge($ax, $bx);
        } elseif ($domainLevel == "sld") {
            $a = $b = $c = $ax = $bx = [];
            foreach ($emails as $email) {
                $x = trim($email);
                if (strpos($x, '@') !== false) {
                    $y = explode("@", $x);
                    $a[] = $y[1];
                    $b[] = $y[0];
                } else {
                    $c[] = $x;
                }
            }

            foreach ($a as $key => $value) {
                $ax[] = $value."@".$b[$key];
            }

            if ($order == "asc") {
                sort($ax, SORT_NATURAL | SORT_FLAG_CASE);
            } elseif ($order == "desc") {
                rsort($ax, SORT_NATURAL | SORT_FLAG_CASE);
            } else {
                sort($ax, SORT_NATURAL | SORT_FLAG_CASE);
            }

            foreach ($ax as $key => $value) {
                list($sld, $local) = explode('@', $value);
                $bx[] = $local.'@'.$sld;
            }

            if ($order == "asc") {
                sort($c, SORT_NATURAL | SORT_FLAG_CASE);
            } elseif ($order == "desc") {
                rsort($c, SORT_NATURAL | SORT_FLAG_CASE);
            } else {
                sort($c, SORT_NATURAL | SORT_FLAG_CASE);
            }
        
            return array_merge($bx, $c);
        } 

        elseif ($domainLevel == "none" && $order == "asc") {
            sort($emails, SORT_NATURAL | SORT_FLAG_CASE);

            return $emails;
        } elseif ($domainLevel == "none" && $order == "desc") {
            rsort($emails, SORT_NATURAL | SORT_FLAG_CASE);

            return $emails;
        }

        return $emails;
    }

}


