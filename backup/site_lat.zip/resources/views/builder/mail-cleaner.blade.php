  <x-app-layout>
  @section('content')

<style type="text/css"> 
    label, .form-label {
    font-size: 14px;
    font-weight: 400;
    margin-bottom: 0.5rem;
    color: #252f40;
    margin-left: 0.25rem;
    font-family: inherit;
}
</style>
        <!-- Kartik fileinput -->
         <link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
         <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

        <link rel="stylesheet" 
        href="public/builder/kartik-v/bootstrap-fileinput/css/fileinput.css" media="all" type="text/css">
        <!-- Simple Sidebar -->
        <link rel="stylesheet" href="public/builder/css/simple-sidebar.css">
        <!-- Select2 -->
        <link rel="stylesheet" 
        href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
        <!-- Bootstrap select2 -->
        <link rel="stylesheet" 
        href="https://cdnjs.cloudflare.com/ajax/libs/select2-bootstrap-theme/0.1.0-beta.10/select2-bootstrap.min.css">
        <!-- Bootstrap extend -->
        <link rel="stylesheet" 
        href="https://cdn.rawgit.com/Chalarangelo/bootstrap-extend/880420ae663f7c539971ded33411cdecffcc2134/css/bootstrap-extend.min.css">
        <!-- Bootstrap tour standalone -->
        <link rel="stylesheet" 
        href="public/builder/bootstrap-tour/build/css/bootstrap-tour-standalone-brv.css">
        <!-- Zebra dialog -->
        <link rel="stylesheet" 
        href="https://cdn.jsdelivr.net/npm/zebra_dialog@latest/dist/css/flat/zebra_dialog.min.css">
        <!-- Custom styles -->
        <link rel="stylesheet" href="public/builder/css/oc-advanced.css">


        <!-- Main fileinput plugin file -->
        <script src="public/builder/kartik-v/bootstrap-fileinput/js/fileinput.js"></script>
        <!-- Optionally if you need a theme like font awesome theme you can include it as mentioned below -->
        <script src="public/builder/kartik-v/bootstrap-fileinput/themes/fa/theme.min.js"></script>
        <!-- Optionally if you need translation for your language then include locale file as mentioned below -->
        <script src="public/builder/kartik-v/bootstrap-fileinput/js/locales/fr.js"></script>
        <!-- Select2 -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
        <!-- Bootstrap extend -->
        <script src="https://cdn.rawgit.com/Chalarangelo/bootstrap-extend/880420ae663f7c539971ded33411cdecffcc2134/js/bootstrap-extend.min.js"></script>
        <!-- Bootstrap tour standalone -->
        <script src="public/builder/bootstrap-tour/build/js/bootstrap-tour-standalone.min.js"></script>
        <!-- Zebra dialog -->
        <script src="https://cdn.jsdelivr.net/npm/zebra_dialog/dist/zebra_dialog.min.js"></script>
        <!-- Custom script -->
        <script type="text/javascript" src="public/builder/js/oc-advanced.js"></script>

 <div class="  py-4"  style="max-height: 700px;background-color:white; "> 
    <p class="h4 text-center"> Welcome to Email Cleaner</p>
</div> 

  <div class=" card m-auto"  style="overflow: hidden;max-height: 700px;background:white;
   width:82%; z-index: 100;">
    <form  method="post" action="{{route('/clean_mail')}}"  enctype="multipart/form-data">@csrf

                       

                        <div class="row card-body" style="background:#f7f7f7;">
                            <div class="col-sm">
                                <div class="form-group" id="usage">
                                    <label for="inputListName">Indicate the name of your list for export (optional)</label>
                                    <input 
                                    type="text" 
                                    class="form-control" 
                                    id="inputListName" 
                                    name="name" 
                                    aria-describedby="nameHelp" 
                                    placeholder="The name of the final file"
                                    spellcheck="false">
                                </div>
                                <div class="form-group" id="options">
                                    <label for="textareaListEmails">Copy/paste your email addresses below</label>
                                    <textarea class="form-control" id="textareaListEmails" name="emails" rows="11" spellcheck="false"></textarea>
                                </div>
                                <div class="row form-group" id="reflex" > 
                                    <div class="col-sm-10"  >  <p class="small control-label"> insert a csv file containing your email addresses</p></div>

                                    <div class="col-sm-2" style="height: 60px;"  >  <input 
                                    id="file-input" 
                                    name="fileInput" 
                                    type="file" 
                                    class="file-loading" 
                                    accept="text/plain" 
                                    data-show-upload="false" 
                                    data-show-remove="true" 
                                    data-show-caption="true">
                                </div>
                                   
                                   
                                </div>


                               <div class="form-group" id="contributing">
                                   <!--  <label for="select-choices">Choose the cleaning level of your email addresses</label>
                                    <select 
                                    class="cleaning-choices" 
                                    id="select-choices" 
                                    name="select-choices" 
                                    data-placeholder="Select an cleaning option" 
                                    style="width: 100%;" 
                                    required>
                                        <option></option>
                                        <option value="1">Level 1 - Validating Email</option>
                                        <option value="2">Level 2 - Level 1 + Domain Validation</option>
                                        <option value="3">Level 3 - Level 1 + Level 2 + SMTP Email Validation</option>
                                    </select> -->
                                </div>
                            </div> 


                            <div class="col-sm ">
                                <div id="order-1">
                                    <label class="text-success" >Sorting options in asc or desc order (optional)</label>
                                    <div class="form-check">
                                        <input type="radio" class="rdbtn rdbtn-primary" name="ascOrDesc" id="noSorting" value="none" checked>
                                        <label for="noSorting">No sorting (leave as is)</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" class="rdbtn rdbtn-primary" name="ascOrDesc" id="ascOrder" value="asc">
                                        <label for="ascOrder">By order ascending or ASC (0-9 a-z)</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" class="rdbtn rdbtn-primary" name="ascOrDesc" id="descOrder" value="desc">
                                        <label for="descOrder">By order descending or DESC (z-a 9-0)</label>
                                    </div>
                                </div>

 
                                <div id="order-2" class="mt-4">
                                    <label class="text-success">Advanced sorting options by domains (optional)</label>
                                    <div class="form-check">
                                        <input type="radio" class="rdbtn rdbtn-primary" name="tldAndSld" id="noDomain" value="none" checked>
                                        <label for="noDomain">No sorting (leave as is)</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" class="rdbtn rdbtn-primary" name="tldAndSld" id="tld" value="tld">
                                        <label for="tld">Top level TLD (eg: .com, .net, .org...)</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" class="rdbtn rdbtn-primary" name="tldAndSld" id="ccTld" value="ccTld">
                                        <label for="ccTld">National top level ccTLD (eg: .ca for Canada, .fr for France...)</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" class="rdbtn rdbtn-primary" name="tldAndSld" id="sld" value="sld">
                                        <label for="sld">Second level SLD (eg: gmail.com, example.org...)</label>
                                    </div>
                                </div>
                                <hr> 


                              <!--  <label><em>Removal options (optional)</em></label>
                                <div id="del-tld">
                                    <label>Advanced TLD and ccTLD removal</label>
                                    <div class="form-group">
                                        <select 
                                        class="aeo-tld" 
                                        id="aeo-tld" 
                                        name="aeo-tld[]" 
                                        data-placeholder="Choose domains to remove from your list" 
                                        multiple="multiple" 
                                        style="width: 100%;">
                                            <optgroup label="Generic domains">
                                                <option value="com">.com</option>
                                                <option value="org">.org</option>
                                                <option value="net">.net</option>
                                                <option value="int">.int</option>
                                                <option value="edu">.edu</option>
                                                <option value="gov">.gov</option>
                                                <option value="mil">.mil</option>
                                            </optgroup>
                                            <optgroup label="Special domains">
                                                <option value="arpa">.arpa</option>
                                            </optgroup>
                                            <optgroup label="A">
                                                <option value="ac">.ac</option>
                                                <option value="ad">.ad</option>
                                                <option value="ae">.ae</option>
                                                <option value="af">.af</option>
                                                <option value="ag">.ag</option>
                                                <option value="ai">.ai</option>
                                                <option value="al">.al</option>
                                                <option value="am">.am</option>
                                                <option value="an">.an</option>
                                                <option value="ao">.ao</option>
                                                <option value="aq">.aq</option>
                                                <option value="ar">.ar</option>
                                                <option value="as">.as</option>
                                                <option value="at">.at</option>
                                                <option value="au">.au</option>
                                                <option value="aw">.aw</option>
                                                <option value="ax">.ax</option>
                                                <option value="az">.az</option>
                                            </optgroup>
                                            <optgroup label="B">
                                                <option value="ba">.ba</option>
                                                <option value="bb">.bb</option>
                                                <option value="bd">.bd</option>
                                                <option value="be">.be</option>
                                                <option value="bf">.bf</option>
                                                <option value="bg">.bg</option>
                                                <option value="bh">.bh</option>
                                                <option value="bi">.bi</option>
                                                <option value="bj">.bj</option>
                                                <option value="bl">.bl</option>
                                                <option value="bm">.bm</option>
                                                <option value="bn">.bn</option>
                                                <option value="bo">.bo</option>
                                                <option value="bq">.bq</option>
                                                <option value="br">.br</option>
                                                <option value="bs">.bs</option>
                                                <option value="bt">.bt</option>
                                                <option value="bu">.bu</option>
                                                <option value="bv">.bv</option>
                                                <option value="bw">.bw</option>
                                                <option value="by">.by</option>
                                                <option value="bz">.bz</option>
                                                <option value="bzh">.bzh</option>
                                            </optgroup>
                                            <optgroup label="C">
                                                <option value="ca">.ca</option>
                                                <option value="cat">.cat</option>
                                                <option value="cc">.cc</option>
                                                <option value="cd">.cd</option>
                                                <option value="cf">.cf</option>
                                                <option value="cg">.cg</option>
                                                <option value="ch">.ch</option>
                                                <option value="ci">.ci</option>
                                                <option value="ck">.ck</option>
                                                <option value="cl">.cl</option>
                                                <option value="cm">.cm</option>
                                                <option value="cn">.cn</option>
                                                <option value="co">.co</option>
                                                <option value="corsica">.corsica</option>
                                                <option value="cr">.cr</option>
                                                <option value="cs">.cs</option>
                                                <option value="cu">.cu</option>
                                                <option value="cv">.cv</option>
                                                <option value="cw">.cw</option>
                                                <option value="cx">.cx</option>
                                                <option value="cy">.cy</option>
                                                <option value="cz">.cz</option>
                                            </optgroup>
                                            <optgroup label="D">
                                                <option value="dd">.dd</option>
                                                <option value="de">.de</option>
                                                <option value="dj">.dj</option>
                                                <option value="dk">.dk</option>
                                                <option value="dm">.dm</option>
                                                <option value="do">.do</option>
                                                <option value="dz">.dz</option>
                                            </optgroup>
                                            <optgroup label="E">
                                                <option value="ec">.ec</option>
                                                <option value="ee">.ee</option>
                                                <option value="eg">.eg</option>
                                                <option value="eh">.eh</option>
                                                <option value="er">.er</option>
                                                <option value="es">.es</option>
                                                <option value="et">.et</option>
                                                <option value="eu">.eu</option>
                                            </optgroup>
                                            <optgroup label="F">
                                                <option value="fi">.fi</option>
                                                <option value="fj">.fj</option>
                                                <option value="fk">.fk</option>
                                                <option value="fm">.fm</option>
                                                <option value="fo">.fo</option>
                                                <option value="fr">.fr</option>
                                            </optgroup>
                                            <optgroup label="G">
                                                <option value="ga">.ga</option>
                                                <option value="gb">.gb</option>
                                                <option value="gd">.gd</option>
                                                <option value="ge">.ge</option>
                                                <option value="gf">.gf</option>
                                                <option value="gg">.gg</option>
                                                <option value="gh">.gh</option>
                                                <option value="gi">.gi</option>
                                                <option value="gl">.gl</option>
                                                <option value="gm">.gm</option>
                                                <option value="gn">.gn</option>
                                                <option value="gp">.gp</option>
                                                <option value="gq">.gq</option>
                                                <option value="gr">.gr</option>
                                                <option value="gs">.gs</option>
                                                <option value="gt">.gt</option>
                                                <option value="gu">.gu</option>
                                                <option value="gw">.gw</option>
                                                <option value="gy">.gy</option>
                                            </optgroup>
                                            <optgroup label="H">
                                                <option value="hk">.hk</option>
                                                <option value="hm">.hm</option>
                                                <option value="hn">.hn</option>
                                                <option value="hr">.hr</option>
                                                <option value="ht">.ht</option>
                                                <option value="hu">.hu</option>
                                            </optgroup>
                                            <optgroup label="I">
                                                <option value="id">.id</option>
                                                <option value="ie">.ie</option>
                                                <option value="il">.il</option>
                                                <option value="im">.im</option>
                                                <option value="in">.in</option>
                                                <option value="io">.io</option>
                                                <option value="iq">.iq</option>
                                                <option value="ir">.ir</option>
                                                <option value="is">.is</option>
                                                <option value="it">.it</option>
                                            </optgroup>
                                            <optgroup label="J">
                                                <option value="je">.je</option>
                                                <option value="jm">.jm</option>
                                                <option value="jo">.jo</option>
                                                <option value="jp">.jp</option>
                                            </optgroup>
                                            <optgroup label="K">
                                                <option value="ke">.ke</option>
                                                <option value="kg">.kg</option>
                                                <option value="kh">.kh</option>
                                                <option value="ki">.ki</option>
                                                <option value="km">.km</option>
                                                <option value="kn">.kn</option>
                                                <option value="kp">.kp</option>
                                                <option value="kr">.kr</option>
                                                <option value="krd">.krd</option>
                                                <option value="kw">.kw</option>
                                                <option value="ky">.ky</option>
                                                <option value="kz">.kz</option>
                                            </optgroup>
                                            <optgroup label="L">
                                                <option value="la">.la</option>
                                                <option value="lb">.lb</option>
                                                <option value="lc">.lc</option>
                                                <option value="li">.li</option>
                                                <option value="lk">.lk</option>
                                                <option value="lr">.lr</option>
                                                <option value="ls">.ls</option>
                                                <option value="lt">.lt</option>
                                                <option value="lu">.lu</option>
                                                <option value="lv">.lv</option>
                                                <option value="ly">.ly</option>
                                            </optgroup>
                                            <optgroup label="M">
                                                <option value="ma">.ma</option>
                                                <option value="mc">.mc</option>
                                                <option value="md">.md</option>
                                                <option value="me">.me</option>
                                                <option value="mf">.mf</option>
                                                <option value="mg">.mg</option>
                                                <option value="mh">.mh</option>
                                                <option value="mk">.mk</option>
                                                <option value="ml">.ml</option>
                                                <option value="mm">.mm</option>
                                                <option value="mn">.mn</option>
                                                <option value="mo">.mo</option>
                                                <option value="mp">.mp</option>
                                                <option value="mq">.mq</option>
                                                <option value="mr">.mr</option>
                                                <option value="ms">.ms</option>
                                                <option value="mt">.mt</option>
                                                <option value="mu">.mu</option>
                                                <option value="mv">.mv</option>
                                                <option value="mw">.mw</option>
                                                <option value="mx">.mx</option>
                                                <option value="my">.my</option>
                                                <option value="mz">.mz</option>
                                            </optgroup>
                                            <optgroup label="N">
                                                <option value="na">.na</option>
                                                <option value="nc">.nc</option>
                                                <option value="ne">.ne</option>
                                                <option value="nf">.nf</option>
                                                <option value="ng">.ng</option>
                                                <option value="ni">.ni</option>
                                                <option value="nl">.nl</option>
                                                <option value="no">.no</option>
                                                <option value="np">.np</option>
                                                <option value="nr">.nr</option>
                                                <option value="nu">.nu</option>
                                                <option value="nz">.nz</option>
                                            </optgroup>
                                            <optgroup label="O">
                                                <option value="om">.om</option>
                                            </optgroup>
                                            <optgroup label="P">
                                                <option value="pa">.pa</option>
                                                <option value="pe">.pe</option>
                                                <option value="pf">.pf</option>
                                                <option value="pg">.pg</option>
                                                <option value="ph">.ph</option>
                                                <option value="pk">.pk</option>
                                                <option value="pl">.pl</option>
                                                <option value="pm">.pm</option>
                                                <option value="pn">.pn</option>
                                                <option value="pr">.pr</option>
                                                <option value="ps">.ps</option>
                                                <option value="pt">.pt</option>
                                                <option value="pw">.pw</option>
                                                <option value="py">.py</option>
                                            </optgroup>
                                            <optgroup label="Q">
                                                <option value="qa">.qa</option>
                                                <option value="quebec">.quebec</option>
                                            </optgroup>
                                            <optgroup label="R">
                                                <option value="re">.re</option>
                                                <option value="ro">.ro</option>
                                                <option value="rs">.rs</option>
                                                <option value="ru">.ru</option>
                                                <option value="rw">.rw</option>
                                            </optgroup>
                                            <optgroup label="S">
                                                <option value="sa">.sa</option>
                                                <option value="sb">.sb</option>
                                                <option value="sc">.sc</option>
                                                <option value="sd">.sd</option>
                                                <option value="se">.se</option>
                                                <option value="sg">.sg</option>
                                                <option value="sh">.sh</option>
                                                <option value="si">.si</option>
                                                <option value="sj">.sj</option>
                                                <option value="sk">.sk</option>
                                                <option value="sl">.sl</option>
                                                <option value="sm">.sm</option>
                                                <option value="sn">.sn</option>
                                                <option value="so">.so</option>
                                                <option value="sr">.sr</option>
                                                <option value="ss">.ss</option>
                                                <option value="st">.st</option>
                                                <option value="su">.su</option>
                                                <option value="sv">.sv</option>
                                                <option value="sx">.sx</option>
                                                <option value="sy">.sy</option>
                                                <option value="sz">.sz</option>
                                            </optgroup>
                                            <optgroup label="T">
                                                <option value="tc">.tc</option>
                                                <option value="td">.td</option>
                                                <option value="tf">.tf</option>
                                                <option value="tg">.tg</option>
                                                <option value="th">.th</option>
                                                <option value="tj">.tj</option>
                                                <option value="tk">.tk</option>
                                                <option value="tl">.tl</option>
                                                <option value="tm">.tm</option>
                                                <option value="tn">.tn</option>
                                                <option value="to">.to</option>
                                                <option value="tp">.tp</option>
                                                <option value="tr">.tr</option>
                                                <option value="tt">.tt</option>
                                                <option value="tv">.tv</option>
                                                <option value="tw">.tw</option>
                                                <option value="tz">.tz</option>
                                            </optgroup>
                                            <optgroup label="U">
                                                <option value="ua">.ua</option>
                                                <option value="ug">.ug</option>
                                                <option value="uk">.uk</option>
                                                <option value="um">.um</option>
                                                <option value="us">.us</option>
                                                <option value="uy">.uy</option>
                                                <option value="uz">.uz</option>
                                            </optgroup>
                                            <optgroup label="V">
                                                <option value="va">.va</option>
                                                <option value="vc">.vc</option>
                                                <option value="ve">.ve</option>
                                                <option value="vg">.vg</option>
                                                <option value="vi">.vi</option>
                                                <option value="vn">.vn</option>
                                                <option value="vu">.vu</option>
                                            </optgroup>
                                            <optgroup label="W">
                                                <option value="wf">.wf</option>
                                                <option value="ws">.ws</option>
                                            </optgroup>
                                            <optgroup label="Y">
                                                <option value="ye">.ye</option>
                                                <option value="yt">.yt</option>
                                                <option value="yu">.yu</option>
                                            </optgroup>
                                            <optgroup label="Z">
                                                <option value="za">.za</option>
                                                <option value="zm">.zm</option>
                                                <option value="zr">.zr</option>
                                                <option value="zw">.zw</option>
                                            </optgroup>
                                        </select>
                                    </div>
                                </div>
                                <div id="del-sld">
                                    <label>Advanced SLD removal</label>
                                    <div class="form-group">
                                        <select 
                                        class="aeo-sld" 
                                        id="aeo-sld" 
                                        name="aeo-sld[]" 
                                        data-placeholder="Choose domains to remove from your list" 
                                        multiple="multiple" 
                                        style="width: 100%;">
                                            <optgroup label="The most used">
                                                <option value="facebook.com">facebook.com</option>
                                                <option value="youtube.com">youtube.com</option>
                                                <option value="yahoo.com">yahoo.com</option>
                                                <option value="live.com">live.com</option>
                                                <option value="msn.com">msn.com</option>
                                                <option value="wikipedia.org">wikipedia.org</option>
                                                <option value="blogspot.com">blogspot.com</option>
                                                <option value="baidu.com">baidu.com</option>
                                                <option value="microsoft.com">microsoft.com</option>
                                                <option value="qq.com">qq.com</option>
                                                <option value="bing.com">bing.com</option>
                                                <option value="ask.com">ask.com</option>
                                                <option value="adobe.com">adobe.com</option>
                                                <option value="taobao.com">taobao.com</option>
                                                <option value="twitter.com">twitter.com</option>
                                                <option value="youku.com">youku.com</option>
                                                <option value="soso.com">soso.com</option>
                                                <option value="wordpress.com">wordpress.com</option>
                                                <option value="sohu.com">sohu.com</option>
                                                <option value="hao123.com">hao123.com</option>
                                                <option value="windows.com">windows.com</option>
                                                <option value="163.com">163.com</option>
                                                <option value="tudou.com">tudou.com</option>
                                                <option value="amazon.com">amazon.com</option>
                                                <option value="apple.com">apple.com</option>
                                                <option value="ebay.com">ebay.com</option>
                                                <option value="4399.com">4399.com</option>
                                                <option value="yahoo.co.jp">yahoo.co.jp</option>
                                                <option value="linkedin.com">linkedin.com</option>
                                                <option value="go.com">go.com</option>
                                                <option value="tmall.com">tmall.com</option>
                                                <option value="paypal.com">paypal.com</option>
                                                <option value="sogou.com">sogou.com</option>
                                                <option value="aol.com">aol.com</option>
                                                <option value="xunlei.com">xunlei.com</option>
                                                <option value="craigslist.org">craigslist.org</option>
                                                <option value="orkut.com">orkut.com</option>
                                                <option value="56.com">56.com</option>
                                                <option value="orkut.com">orkut.com.br</option>
                                                <option value="about.com">about.com</option>
                                                <option value="skype.com">skype.com</option>
                                                <option value="7k7k.com">7k7k.com</option>
                                                <option value="dailymotion.com">dailymotion.com</option>
                                                <option value="flickr.com">flickr.com</option>
                                                <option value="pps.tv">pps.tv</option>
                                                <option value="qiyi.com">qiyi.com</option>
                                                <option value="bbc.co.uk">bbc.co.uk</option>
                                                <option value="4shared.com">4shared.com</option>
                                                <option value="mozilla.com">mozilla.com</option>
                                                <option value="mail.ru">mail.ru</option>
                                                <option value="booking.com">booking.com</option>
                                                <option value="tripadvisor.com">tripadvisor.com</option>
                                                <option value="hotmail.com">hotmail.com</option>
                                                <option value="gmail.com">gmail.com</option>
                                            </optgroup>
                                            <optgroup label="Domains by country code: Australia">
                                                <option value=".asn.au">.asn.au</option>
                                                <option value=".com.au">.com.au</option>
                                                <option value=".net.au">.net.au</option>
                                                <option value=".id.au">.id.au</option>
                                                <option value=".org.au">.org.au</option>
                                                <option value=".edu.au">.edu.au</option>
                                                <option value=".gov.au">.gov.au</option>
                                                <option value=".csiro.au">.csiro.au</option>
                                                <option value=".act.au">.act.au</option>
                                                <option value=".nsw.au">.nsw.au</option>
                                                <option value=".nt.au">.nt.au</option>
                                                <option value=".qld.au">.qld.au</option>
                                                <option value=".sa.au">.sa.au</option>
                                                <option value=".tas.au">.tas.au</option>
                                                <option value=".vic.au">.vic.au</option>
                                                <option value=".wa.au">.wa.au</option>
                                            </optgroup>
                                            <optgroup label="Domains by country code: Austria">
                                                <option value=".co.at">.co.at</option>
                                                <option value=".or.at">.or.at</option>
                                                <option value=".priv.at">.priv.at</option>
                                                <option value=".ac.at">.ac.at</option>
                                            </optgroup>
                                            <optgroup label="Domains by country code: France">
                                                <option value=".avocat.fr">.avocat.fr</option>
                                                <option value=".aeroport.fr">.aeroport.fr</option>
                                                <option value=".veterinaire.fr">.veterinaire.fr</option>
                                            </optgroup>
                                            <optgroup label="Domains by country code: Hungary">
                                                <option value=".co.hu">.co.hu</option>
                                                <option value=".film.hu">.film.hu</option>
                                                <option value=".lakas.hu">.lakas.hu</option>
                                                <option value=".ingatlan.hu">.ingatlan.hu</option>
                                                <option value=".sport.hu">.sport.hu</option>
                                                <option value=".hotel.hu">.hotel.hu</option>
                                            </optgroup>
                                            <optgroup label="Domains by country code: New Zealand">
                                                <option value=".ac.nz">.ac.nz</option>
                                                <option value=".co.nz">.co.nz</option>
                                                <option value=".geek.nz">.geek.nz</option>
                                                <option value=".gen.nz">.gen.nz</option>
                                                <option value=".kiwi.nz">.kiwi.nz</option>
                                                <option value=".maori.nz">.maori.nz</option>
                                                <option value=".net.nz">.net.nz</option>
                                                <option value=".org.nz">.org.nz</option>
                                                <option value=".school.nz">.school.nz</option>
                                                <option value=".cri.nz">.cri.nz</option>
                                                <option value=".govt.nz">.govt.nz</option>
                                                <option value=".health.nz">.health.nz</option>
                                                <option value=".iwi.nz">.iwi.nz</option>
                                                <option value=".mil.nz">.mil.nz</option>
                                                <option value=".parliament.nz">.parliament.nz</option>
                                            </optgroup>
                                            <optgroup label="Domains by country code: Israel">
                                                <option value=".ac.il">.ac.il</option>
                                                <option value=".co.il">.co.il</option>
                                                <option value=".net.il">.net.il</option>
                                                <option value=".net.il">.net.il</option>
                                                <option value=".k12.il">.k12.il</option>
                                                <option value=".gov.il">.gov.il</option>
                                                <option value=".muni.il">.muni.il</option>
                                                <option value=".idf.il">.idf.il</option>
                                            </optgroup>
                                            <optgroup label="Domains by country code: South Africa">
                                                <option value=".ac.za">.ac.za</option>
                                                <option value=".gov.za">.gov.za</option>
                                                <option value=".law.za">.law.za</option>
                                                <option value=".mil.za">.mil.za</option>
                                                <option value=".nom.za">.nom.za</option>
                                                <option value=".school.za">.school.za</option>
                                                <option value=".net.za">.net.za</option>
                                            </optgroup>
                                            <optgroup label="Domains by country code: Ukraine">
                                                <option value=".gov.ua">.gov.ua</option>
                                                <option value=".com.ua">.com.ua</option>
                                                <option value=".in.ua">.in.ua</option>
                                                <option value=".org.ua">.org.ua</option>
                                                <option value=".net.ua">.net.ua</option>
                                                <option value=".edu.ua">.edu.ua</option>
                                            </optgroup>
                                            <optgroup label="Domains by country code: United Kingdom">
                                                <option value=".co.uk">.co.uk</option>
                                                <option value=".org.uk">.org.uk</option>
                                                <option value=".me.uk">.me.uk</option>
                                                <option value=".ltd.uk">.ltd.uk</option>
                                                <option value=".plc.uk">.plc.uk</option>
                                                <option value=".net.uk">.net.uk</option>
                                                <option value=".sch.uk">.sch.uk</option>
                                                <option value=".ac.uk">.ac.uk</option>
                                                <option value=".gov.uk">.gov.uk</option>
                                                <option value=".mod.uk">.mod.uk</option>
                                                <option value=".mil.uk">.mil.uk</option>
                                                <option value=".nhs.uk">.nhs.uk</option>
                                                <option value=".police.uk">.police.uk</option>
                                            </optgroup>
                                        </select>
                                    </div>
                                </div> -->


                            </div>
                        </div>
                      
                        <div class="d-flex justify-content-center">
                            <button style="background: black;" id="launchs" type="submit" class="font-weight-bold text-light btn ">Clean/Sort my emails </button>
                        </div>
                    </form>
                    </div>


                    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
       
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
@endsection

</x-app-layout>